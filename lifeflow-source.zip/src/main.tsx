import React from 'react';
import {createRoot} from 'react-dom/client';
import '@fontsource-variable/noto-sans-arabic';
import App from './Entry';
import PwaStatus from './PwaStatus';
import './style.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><App/><PwaStatus/></React.StrictMode>);
