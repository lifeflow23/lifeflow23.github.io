import {normalize,comparable,namedRecords,productCategory,splitGroceries,isGroceryItem,verbs,minorUnits,amountIn,purchasePrice} from './normalize';
import {resolveDate,riyadhDate,validDate} from './dates';
import type {Action,Clarification,Context,Kind,NewRecord,Proposal,RecordItem,Store} from './model';
const ready=(actions:Action[],reason='جاهز للحفظ'):Proposal=>({outcome:'ready',actions,reason});
const review=(reason:string):Proposal=>({outcome:'review',actions:[],reason});
const clarify=(c:Clarification):Proposal=>({outcome:'clarify',actions:[],reason:c.question,clarification:c});
const create=(kind:Kind,title:string,fields:Partial<NewRecord>={},key='main'):Action=>({type:'create',key,record:{kind,title,status:'open',...fields}});
const update=(r:RecordItem,patch:Partial<RecordItem>):Proposal=>ready([{type:'update',id:r.id,patch}]);
const isProposal=(v:RecordItem|Proposal):v is Proposal=>'outcome' in v;
function resolve(records:RecordItem[],kind:Kind,subject:string,ctx:Context):RecordItem|Proposal {
 const candidates=records.filter(r=>r.kind===kind&&r.status!=='cancelled');
 const found=ctx.record?candidates.filter(r=>r.id===ctx.record):namedRecords(candidates,subject);
 if(found.length===1)return found[0];
 if(!found.length)return review(`ما لقينا سجل ${subject||'مطابق'}. ما تغيّر أي سجل.`);
 return clarify({field:'record',targetKind:kind,question:'فيه أكثر من سجل مطابق. أي واحد تقصد؟',choices:found.map(r=>({label:`${r.title} · ${r.date||r.createdAt.slice(0,10)} · ${r.id.slice(0,6)}`,value:r.id}))});
}
function vehicle(s:Store,t:string,c:Context):RecordItem|Proposal {
 const cars=s.records.filter(r=>r.kind==='vehicle');if(c.vehicle){const car=cars.find(r=>r.id===c.vehicle);return car||review('المركبة المختارة غير موجودة الآن.')}
 const alias=s.preferences.aliases.filter(a=>a.kind==='vehicle'&&t.includes(normalize(a.word)));
 const matches=cars.filter(r=>t.includes(normalize(r.title))||alias.some(a=>a.value===r.id));
 if(matches.length===1)return matches[0];if(cars.length===1)return cars[0];
 return clarify({field:'vehicle',question:cars.length?'أي سيارة تقصد؟':'أضف مركبتك من مساحتي أولًا، ثم كمّل الطلب.',choices:cars.map(r=>({label:r.title,value:r.id}))});
}
function account(s:Store,t:string,c:Context):RecordItem|Proposal {const accounts=s.records.filter(r=>r.kind==='account');const found=c.account?accounts.filter(r=>r.id===c.account):accounts.filter(r=>t.includes(normalize(r.title)));if(found.length===1)return found[0];if(!c.account&&accounts.length===1)return accounts[0];return clarify({field:'account',question:accounts.length?'على أي حساب نسجل العملية؟':'أضف حسابًا ماليًا برصيده المعروف من مساحتي، ثم كمّل الطلب.',choices:accounts.map(r=>({label:r.title,value:r.id}))})}
function cleanTitle(t:string){return t.replace(/^(?:مهم جدا|عاجل|ضروري|مستعجل)\s+/,'').replace(verbs.create,'').replace(/^(?:مهمه|موعد|ب|ان )\s*/,'').replace(/\s*(?:اليوم|بعد بكره|بكره|امس|الاسبوع الجاي|الشهر الجاي|\d{4}-\d{2}-\d{2}|(?:كل )?(?:الاحد|الاثنين|الثلاثاء|الاربعاء|الخميس|الجمعه|السبت)(?: القادم| الجاي)?|الساعه\s*\d{1,2}(?::\d{2})?(?:\s*(?:صباحا?|مساءا?|ص|م|العصر|الظهر|الليل))?|كل يوم|كل شهر|كل 6 شهور|لمده شهر|بعد ساعتين|بعد ساعه|عاجل|ضروري|مستعجل|مهم جدا|باسرع وقت)\s*/g,' ').replace(/\s+/g,' ').trim()}
export function plan(original:string,s:Store,now=new Date(),ctx:Context={}):Proposal {
 let t=normalize(original);if(!t||t.length>2000)return review('اكتب طلبًا واضحًا لا يزيد عن 2000 حرف.');
 if(/(?:^|\s)(?:يمكن|تقريبا|اظن|ماني متاكد|مو متاكد)(?:\s|$)/.test(t))return review('فيه احتمال أو عدم تأكد؛ حدد المعلومة قبل التسجيل.');
 if(/\sاو\s/.test(t)&&!/^احفظ|^سجل ملاحظه|^اكتب فكره/.test(t))return review('فيه خياران محتملان؛ حدد اختيارًا واحدًا قبل التنفيذ.');
 if(/^(اشتريت|شريت|خذت|دفعت|سددت|غيرت زيت)/.test(t)&&/بكره|القادم|الجاي|المستقبل/.test(t))return review('الفعل مكتمل لكن التاريخ مستقبلي؛ وضّح إذا هذا شراء فعلي أو نية.');
 if(ctx.oil)t=t.replace(/زيت(?! الطبخ| طبخ| السياره| سياره)/g,ctx.oil==='cooking'?'زيت طبخ':'زيت السياره');
 if(/(?:كان معي|باقي معي).*(?:اشتريت|دفعت)|(?:اشتريت|دفعت|غيرت زيت).*(?:باقي معي|كان معي)/.test(t))return review('هل الرصيد قبل العملية أو بعدها؟ افصل تأكيد الرصيد عن تسجيل الشراء بعد توضيح ذلك.');
 if(t==='تراجع')return ready([{type:'undo'}]);
 if(/^غير التاريخ ل/.test(t)||t==='رجع المهمه'){
  const latest=[...s.audit].reverse().find(a=>!a.undone);const targets=latest?.after.filter(r=>['task','event','followup'].includes(r.kind))||[];
  if(targets.length!==1||now.getTime()-Date.parse(latest!.at)>15*60000)return review('حدد السجل المقصود؛ ما فيه مرجع حديث واحد واضح.');
  const r=s.records.find(x=>x.id===targets[0].id);if(!r)return review('السجل غير موجود');if(t==='رجع المهمه')return r.kind==='task'?update(r,{status:'open',completedAt:undefined}):review('آخر سجل مو مهمة');
  const d=resolveDate(t,now,ctx);if(d.reason)return clarify({field:d.field||'date',question:d.reason});if(!d.date)return clarify({field:'date',question:'حدد التاريخ الجديد'});return update(r,{date:d.date});
 }
 if(/^لا[,،]? اقصد /.test(t)){
  const amounts=t.match(/^لا[,،]? اقصد (\d+(?:\.\d{1,2})?) مو (\d+(?:\.\d{1,2})?)$/);if(!amounts)return review('حدد التصحيح بالأرقام والسجل المقصود.');
  const latest=[...s.audit].reverse().find(a=>!a.undone);const targets=latest?.after.filter(r=>r.kind==='transaction'&&r.amountMinor===minorUnits(amounts[2]))||[];
  if(targets.length!==1||now.getTime()-Date.parse(latest!.at)>15*60000)return review('ما فيه عملية أخيرة واحدة تطابق المبلغ خلال آخر 15 دقيقة. حدد السجل يدويًا.');
  const r=s.records.find(x=>x.id===targets[0].id);return r?update(r,{amountMinor:minorUnits(amounts[1])}):review('العملية لم تعد موجودة.');
 }
 if(/(?:^|\s)(?:مو|مب|لا)(?:\s|$)/.test(t)&&!/^لا (?:تسجل|تحذف|تضيف|تضف)/.test(t))return review('فيه نفي أو تصحيح غير محسوم؛ ما نفذنا أي تغيير.');
 const explicitDates=t.match(/\d{4}-\d{2}-\d{2}/g)||[];if(new Set(explicitDates).size>1||/اليوم.*بكره|بكره.*اليوم|امس.*بكره|بكره.*امس/.test(t))return review('فيه أكثر من تاريخ محتمل. حدد تاريخًا واحدًا.');
 // Questions are read-only, and never fall through to a creation rule.
 if(/^(?:وش|كم|وين|متي|متى|هل|ابي اعرف|ابغى اعرف)/.test(t)){
  if(/سعر/.test(t))return ready([{type:'query',kind:'price',query:t.replace(/^.*سعر\s*/,'')}]);
  if(/فاتوره|ملف|مستند/.test(t))return ready([{type:'query',kind:'document',query:t.replace(/^وين\s*(?:فاتوره|ملف|مستند)\s*/,'')}]);
  if(/صرفت/.test(t))return ready([{type:'query',kind:'transaction',scope:'month-expenses'}]);
  if(/المتاخر/.test(t))return ready([{type:'query',scope:'overdue'}]);
  if(/انجزت/.test(t))return ready([{type:'query',scope:/الاسبوع/.test(t)?'completed-week':'done'}]);
  if(/عندي/.test(t)){const d=ctx.date?{date:ctx.date}:resolveDate(t,now,ctx);if(d.reason)return clarify({field:d.field||'date',question:d.reason});return ready([{type:'query',scope:'schedule',date:d.date||riyadhDate(now)}])}
  return review('السؤال غير مدعوم بقواعد البحث الحالية. استخدم البحث في المساحة المطلوبة.');
 }
 if(/^(?:لا تسجل|لا تحذف|لا تضيف|لا تضف|مو |مب |افكر |لو |يمكن |يمكنني )/.test(t))return review('هذا نفي أو احتمال، وليس إذنًا لتنفيذ إجراء.');
 if(/^ما (?:شريت|اشتريت|خذت) /.test(t))return review('لم تُسجّل عملية شراء. تقدر تراجع حالة العنصر يدويًا.');
 if(/^ما (?:خلصت|سويت|انجزت|دفعت|سددت)/.test(t))return review('النص ينفي الإنجاز أو الدفع؛ لم تتغيّر السجلات.');
 if(/^(?:احذف|الغ|الغي|كنسل)\s+/.test(t)){
  const kind:Kind=/موعد|اجتماع|مناسبه/.test(t)?'event':'task';const subject=t.replace(/^(?:احذف|الغ|الغي|كنسل)\s+(?:مهمه |موعد )?/,'');const r=resolve(s.records,kind,subject,ctx);if(isProposal(r))return r;if(!ctx.confirm)return clarify({field:'confirm',question:`تلغي «${r.title}»؟ بيبقى في السجل وتقدر تتراجع.`,choices:[{label:'تأكيد الإلغاء',value:'yes'}]});return update(r,{status:'cancelled'});
 }
 if(/زيت/.test(t)&&!/(?:زيت (?:طبخ|الطبخ|زيتون|الزيتون|السياره|سياره|المحرك))/.test(t))return clarify({field:'oil',question:'تقصد زيت سيارة أو زيت طبخ؟',choices:[{label:'زيت طبخ',value:'cooking'},{label:'زيت سيارة',value:'vehicle'}]});
 if(/^رجعوا لي/.test(t)){const n=amountIn(t);const expenses=s.records.filter(r=>r.kind==='transaction'&&r.type==='expense');const r=ctx.record?expenses.find(r=>r.id===ctx.record):undefined;if(!r)return clarify({field:'record',targetKind:'transaction',question:'المبلغ مسترد من أي عملية؟',choices:expenses.map(r=>({label:r.title,value:r.id}))});if(n===undefined)return review('حدد مبلغ الاسترداد.');return ready([create('transaction','استرداد '+r.title,{type:'refund',amountMinor:n,accountId:r.accountId,relatedId:r.id})])}
 if(/^رجعت .*للمحل/.test(t)){const r=resolve(s.records,'grocery',t.replace(/^رجعت /,'').replace(/ للمحل.*$/,''),ctx);if(isProposal(r))return r;return update(r,{status:'returned'})}
 if(/^كان معي/.test(t)){const m=t.match(/^كان معي (\d+(?:\.\d{1,2})?) والحين (\d+(?:\.\d{1,2})?)$/);if(!m)return review('حدد الرصيد السابق والحالي بدقة.');const a=account(s,t,ctx);if(isProposal(a))return a;if(!ctx.confirm)return clarify({field:'confirm',question:`الفرق المذكور ${((minorUnits(m[1])!-minorUnits(m[2])!)/100).toFixed(2)} ر.س. نعتمد الرصيد الحالي كتسوية للحساب، بدون مصروف جديد؟`,choices:[{label:'اعتماد التسوية',value:'yes'}]});return ready([create('transaction','تسوية الرصيد',{type:'reconciliation',amountMinor:minorUnits(m[2]),accountId:a.id,baselineIds:s.records.filter(r=>r.kind==='transaction').map(r=>r.id)})])}
 if(/^باقي معي/.test(t)){const m=t.match(/^باقي معي (\d+(?:\.\d{1,2})?|الفين|الف) وزعها للراتب$/);if(!m)return review('اكتب مثل: باقي معي 2000 وزعها للراتب.');return ready([create('transaction','مبلغ الصرف حتى الراتب',{type:'allowance',amountMinor:minorUnits(m[1]),baselineIds:s.records.filter(r=>r.kind==='transaction').map(r=>r.id)})])}
 if(/^حولت /.test(t)){const m=t.match(/^حولت (\d+(?:\.\d{1,2})?) من (.+) (?:الي |ل)(.+)$/);if(!m)return review('حدد المبلغ والحسابين: حولت 500 من البنك للكاش.');const from=namedRecords(s.records.filter(r=>r.kind==='account'),m[2]);const to=namedRecords(s.records.filter(r=>r.kind==='account'),m[3].startsWith('ل')?'ا'+m[3]:m[3]);if(from.length!==1||to.length!==1||from[0].id===to[0].id)return review('الحسابان غير محددين بشكل فريد أو الحسابان نفسهما.');return ready([create('transaction','تحويل داخلي',{type:'transfer',amountMinor:minorUnits(m[1]),accountId:from[0].id,toAccountId:to[0].id})])}
 if(/^(?:حط|خصصت|خصص) .*?(?:للطوارئ|للادخار|للاستثمار|لهدف)/.test(t)){const n=amountIn(t);if(n===undefined)return review('حدد مبلغ التخصيص.');let relatedId:string|undefined;if(/لهدف/.test(t)){const r=resolve(s.records,'goal',t.split('لهدف')[1].trim(),ctx);if(isProposal(r))return r;relatedId=r.id}return ready([create('transaction',t.replace(/^(حط|خصصت|خصص) /,''),{type:'allocation',amountMinor:n,relatedId})])}
 if(/^نزل راتبي/.test(t)){let rest=t.replace(/^نزل راتبي\s*/,'');for(const a of s.records.filter(r=>r.kind==='account'))rest=rest.replace(new RegExp(` في (?:حساب )?${normalize(a.title)}$`),'');const n=minorUnits(rest);if(n===undefined)return review('حدد مبلغ راتب واحدًا بدقة.');const a=account(s,t,ctx);if(isProposal(a))return a;return ready([create('transaction','راتب',{type:'income',amountMinor:n,accountId:a.id})])}
 if(/^(?:دفعت|سددت) /.test(t)){const n=amountIn(t);if(n===undefined)return review('حدد المبلغ والحساب لتسجيل الدفع.');const a=account(s,t,ctx);if(isProposal(a))return a;const title=t.replace(/^(دفعت|سددت) /,'').replace(/\s*\d.*$/,'').trim();const bills=namedRecords(s.records.filter(r=>r.kind==='task'&&r.category==='bill'),title);if(bills.length>1)return clarify({field:'record',targetKind:'task',question:'أي فاتورة تقصد؟',choices:bills.map(r=>({label:r.title,value:r.id}))});const bill=ctx.record?s.records.find(r=>r.id===ctx.record):bills[0];return ready([create('transaction',title||'دفعة',{type:'expense',amountMinor:n,accountId:a.id,...(bill?{relatedId:bill.id}:{})}),...(bill?[{type:'update' as const,id:bill.id,patch:{status:'done' as const,completedAt:now.toISOString()}}]:[])])}
 if(/^ممشي /.test(t)){const car=vehicle(s,t,ctx);if(isProposal(car))return car;const n=t.match(/(\d+)$/);if(!n)return review('حدد قراءة العداد بالكيلومتر.');if(car.mileage!==undefined&&+n[1]<car.mileage&&!ctx.confirm)return clarify({field:'confirm',question:'القراءة أقل من السابقة. تعتمد تصحيح العداد؟',choices:[{label:'تأكيد التصحيح',value:'yes'}]});return update(car,{mileage:+n[1]})}
 if(/^غيرت زيت|^صلحت السياره|^عبيت بنزين/.test(t)||/^(اشتريت|شريت)/.test(t)&&(ctx.oil==='vehicle'||/زيت (?:السياره|سياره|المحرك)/.test(t))){
  const car=vehicle(s,t,ctx);if(isProposal(car))return car;const price=purchasePrice(t,s.records.filter(r=>r.kind==='account').map(r=>r.title));if(price.invalid)return review('مبلغ الصيانة غير واضح؛ حدد قيمة واحدة بدقة.');const n=price.value;const a=n!==undefined?account(s,t,ctx):undefined;if(a&&isProposal(a))return a;
  const title=/بنزين/.test(t)?'تعبئة وقود':/^(اشتريت|شريت)/.test(t)?'شراء زيت للمركبة':/زيت/.test(t)?'تغيير زيت':'إصلاح مركبة';const actions:Action[]=[create('maintenance',title,{vehicleId:car.id,status:'done',date:riyadhDate(now)})];if(n!==undefined&&a)actions.push({...create('transaction',title,{type:'expense',amountMinor:n,accountId:(a as RecordItem).id},'expense') as Extract<Action,{type:'create'}>,linkKey:'main'});return ready(actions)
 }
 if(/التامين ينتهي|الاستماره تنتهي/.test(t)){const car=vehicle(s,t,ctx);if(isProposal(car))return car;const d=ctx.date?{date:ctx.date}:resolveDate(t,now,ctx);if(!d.date)return clarify({field:'date',question:d.reason||'وش تاريخ الانتهاء كاملًا بالسنة؟'});return ready([create('task',/التامين/.test(t)?'تجديد التأمين':'تجديد الاستمارة',{date:d.date,vehicleId:car.id,category:'personal'})])}
 if(/^ضمان .+ ينتهي/.test(t)){const subject=t.replace(/^ضمان /,'').split(' ينتهي')[0];const asset=resolve(s.records,'asset',subject,ctx);if(isProposal(asset))return asset;const d=ctx.date?{date:ctx.date}:resolveDate(t,now,ctx);if(!d.date)return clarify({field:'date',question:d.reason||'حدد تاريخ انتهاء الضمان كاملًا.'});return update(asset,{date:d.date})}
 if(/^بعت /.test(t)){const asset=resolve(s.records,'asset',t.slice(4),ctx);return isProposal(asset)?asset:update(asset,{status:'sold'})}
 if(/(?:المكيف|الغساله|الثلاجه|الفرن|الماء|الباب) خرب/.test(t))return ready([create('issue',t,{category:'home'})]);
 if(/^صلحت /.test(t)){const r=resolve(s.records,'issue',t.slice(5),ctx);return isProposal(r)?r:update(r,{status:'done',completedAt:now.toISOString()})}
 if(/^هدفي /.test(t)){const m=t.match(/^هدفي اجمع (\d+(?:\.\d{1,2})?)(?: (.+))?$/);if(m)return ready([create('goal',m[2]||'هدف ادخار',{targetMinor:minorUnits(m[1])})]);return ready([create('goal',t.slice(5))])}
 if(/^(?:احفظ|سجل|اكتب) (?:هالمعلومه|ملاحظه|فكره)/.test(t)){const content=ctx.content||original.replace(/^(?:احفظ|سجل|اكتب)\s+(?:هالمعلومة|هالمعلومه|ملاحظة|ملاحظه|فكرة|فكره)\s*[:：]?\s*/,'').trim();if(!content||normalize(content)===t)return clarify({field:'content',question:'وش المعلومة اللي تبي تحفظها؟'});return ready([create('note',content.slice(0,80),{content})])}
 if(/^(.+) رد وانتهي الموضوع$/.test(t)){const r=resolve(s.records,'followup',t.replace(/ رد وانتهي الموضوع$/,''),ctx);return isProposal(r)?r:update(r,{status:'done',completedAt:now.toISOString()})}
 if(/^(.+) بيرد علي /.test(t)){const person=t.split(' بيرد علي ')[0];const d=ctx.date?{date:ctx.date}:resolveDate(t,now,ctx);if(d.reason)return clarify({field:'date',question:d.reason});if(!d.date)return clarify({field:'date',question:'متى تبي تتابع الرد؟'});return ready([create('followup','متابعة '+person,{date:d.date,category:'personal'})])}
 if(verbs.complete.test(t)||/^(?:رجع المهمه|اعد فتح المهمه) /.test(t)){
  const reopen=/^(رجع|اعد فتح)/.test(t);const title=t.replace(/^(?:خلصت|انتهيت|سويت|تم|انجزت|رجع|اعد فتح)\s+(?:مهمه |المهمه )?/,'');if(/الموضوع|اللي قلنا|هذا|ذاك/.test(title))return review('المرجع غير محدد؛ اختر المهمة بالاسم.');const r=resolve(s.records,'task',title,ctx);return isProposal(r)?r:update(r,{status:reopen?'open':'done',completedAt:reopen?undefined:now.toISOString()})
 }
 if(verbs.modify.test(t)){
  let subject=t.replace(verbs.modify,'').replace(/^(?:مهمه|المهمه|موعد) /,'');const kind:Kind=/موعد|اجتماع/.test(t)?'event':'task';let patch:Partial<RecordItem>={};
  const titleChange=subject.match(/^(.+) (?:الي|إلى) (.+)$/);const category=subject.match(/^(.+) (?:للعمل|للشخصي)$/);const priority=subject.match(/^(.+) (?:عاجل|عادي)$/);
  const dates=ctx.date?{date:ctx.date,time:ctx.time}:resolveDate(t,now,ctx);
  if(titleChange&&/^غير|^عدل/.test(t)){subject=titleChange[1];patch={title:titleChange[2]}}
  else if(category){subject=category[1];patch={category:/للعمل$/.test(t)?'work':'personal'}}
  else if(priority){subject=priority[1];patch={urgent:/عاجل$/.test(t)}}
  else {subject=cleanTitle(subject).replace(/\s*لل?اسبوع الجاي.*|\s*لل?شهر الجاي.*/,'');patch={...(dates.date?{date:dates.date}:{}),...(dates.time?{time:dates.time}:{})}}
  const r=resolve(s.records,kind,subject,ctx);if(isProposal(r))return r;if(dates.reason&&!Object.keys(patch).length)return clarify({field:dates.field||'date',question:dates.reason});if(!Object.keys(patch).length)return clarify({field:'date',question:'وش التاريخ الجديد بالضبط؟'});return update(r,patch)
 }
 const purchase=/^(?:اشتريت|شريت|خذت)\s+/.test(t);
 const bareGroceries=splitGroceries(t);
 const shopping=(bareGroceries.length>0&&bareGroceries.every(x=>isGroceryItem(x,s.preferences.aliases)))||/(?:للمقاضي|للمشتريات)$/.test(t)||/^(?:نحتاج|ناقصنا|احتاج) /.test(t)||verbs.create.test(t)&&isGroceryItem(t.replace(verbs.create,''),s.preferences.aliases)||!!productCategory(t,s.preferences.aliases)&&/ضروري$/.test(t);
 if(purchase||shopping){
  let text=t.replace(/^(?:اشتريت|شريت|خذت)\s+|^(?:اضف|ضيف|حط|سجل|احتاج|نحتاج|ناقصنا)\s+/,'').replace(/\s*(?:للمقاضي|للمشتريات)$/,'').replace(/\s*(?:بـ?|بمبلغ)\s*(?:\d+(?:\.\d{1,2})?|الفين|الف)(?:\s*(?:ريال|ر\.س))?.*$/,'').replace(/\s+ضروري$/,'').trim();
  const price=purchasePrice(t,s.records.filter(r=>r.kind==='account').map(r=>r.title));const n=purchase?price.value:undefined;if(purchase&&price.invalid)return review('المبلغ غير صالح. استخدم مبلغًا موجبًا حتى منزلتين عشريتين.');const a=n!==undefined?account(s,t,ctx):undefined;if(a&&isProposal(a))return a;
  const items=splitGroceries(text);if(!items.length)return review('اسم المشتريات ناقص.');if(n!==undefined&&items.length>1)return review('حدد هل السعر إجمالي أو لكل عنصر قبل تسجيل المصروف.');
  const actions:Action[]=[];for(let i=0;i<items.length;i++){const raw=items[i];const qty=raw.match(/\s+(\d+(?:\.\d+)?\s*(?:كيلو|لتر|حبه|حبات|شدات|شده)?|شدتين|حبتين|كيلوين|نص كيلو|ربع كيلو)$/);const title=qty?raw.slice(0,-qty[0].length):raw;if(!title||title.length<2)return review('اسم المنتج غير واضح.');
   const isAsset=/^(?:ثلاجه|غساله|تلفزيون|مكيف|لابتوب)$/.test(title);if(purchase&&!isAsset&&!productCategory(title,s.preferences.aliases))return review('نوع المشتريات غير محدد بقواعد موثوقة؛ اختر المساحة يدويًا.');if(!purchase&&isAsset)return review('حدد إذا تبي مهمة شراء أو تسجيل أصل.');
   const kind:Kind=isAsset?'asset':'grocery';const existing=namedRecords(s.records.filter(r=>r.kind===kind&&r.status==='open'),title);if(existing.length>1)return clarify({field:'record',targetKind:kind,question:'أي عنصر تقصد؟',choices:existing.map(r=>({label:r.title,value:r.id}))});
   const chosen=ctx.record?s.records.find(r=>r.id===ctx.record&&r.kind===kind):existing[0];
   if(!purchase&&chosen)return review('العنصر موجود أصلًا. عدل الكمية من قائمته بدل إضافة نسخة ثانية.');
   const key='item'+i;if(purchase&&chosen){actions.push({type:'update',id:chosen.id,patch:{status:'done',completedAt:now.toISOString()}});if(n!==undefined&&a)actions.push(create('transaction','شراء '+title,{type:'expense',amountMinor:n,accountId:(a as RecordItem).id,relatedId:chosen.id},'expense'+i))}
   else {actions.push(create(kind,title,{status:purchase?'done':'open',category:productCategory(title,s.preferences.aliases)||'غير مصنف',quantity:qty?.[1],favorite:/ضروري/.test(t)},key));if(n!==undefined&&a)actions.push({...create('transaction','شراء '+title,{type:'expense',amountMinor:n,accountId:(a as RecordItem).id},'expense'+i) as Extract<Action,{type:'create'}>,linkKey:key})}
  }return ready(actions)
 }
 const appointment=/^(?:عندي |حط موعد |اضف موعد |ضيف موعد |سجل موعد |كل )/.test(t)&&/موعد|اجتماع|مناسبه/.test(t);
 const task=/^(?:ذكرني|اضف مهمه|ضيف مهمه|حط مهمه|سجل مهمه|اكتب مهمه|سو مهمه|خل مهمه|عاجل |ضروري |مستعجل |ودي |بشتري |لازم اليوم)/.test(t);
 if(appointment||task){
  let vehicleId:string|undefined;if(/صيانه السياره|تامين السياره|زيت السياره|ودي اغير الكفرات/.test(t)){const car=vehicle(s,t,ctx);if(isProposal(car))return car;vehicleId=car.id}
  const d=resolveDate(t,now,ctx);if(d.reason&&!(d.field==='date'?ctx.date:ctx.time))return clarify({field:d.field||'date',question:d.reason});const date=ctx.date||d.date,time=ctx.time||d.time;
  if(appointment&&!date)return clarify({field:'date',question:'وش تاريخ الموعد؟'});
  let title=ctx.content||cleanTitle(t).replace(/^عندي /,'').replace(/^ودي /,'').replace(/^بشتري /,'شراء ').replace(/^لازم /,'').trim();if(title.length<3||['مهمه','شي','شيء'].includes(title))return clarify({field:'content',question:'وش اسم المهمة أو الموعد؟'});if(ctx.content)title=ctx.content;
  let endTime:string|undefined;const duration=t.match(/لمده (\d+) دقيقه/);if(duration&&time){const [h,m]=time.split(':').map(Number);const end=h*60+m+Number(duration[1]);if(end>=1440)return review('الموعد يعبر منتصف الليل؛ حدد الموعد يدويًا.');endTime=`${String(Math.floor(end/60)).padStart(2,'0')}:${String(end%60).padStart(2,'0')}`}
  return ready([create(appointment?'event':'task',title,{category:/عمل|الفريق|المشروع|اجتماع/.test(t)?'work':'personal',urgent:/^(عاجل|ضروري|مستعجل)|مهم جدا|لازم اليوم|باسرع وقت/.test(t),date,time,endTime,recurrence:d.recurrence,vehicleId})]);
 }
 if(/^اعرض (?:المهام|مهامي)/.test(t))return ready([{type:'query',kind:'task',scope:/المكتمله/.test(t)?'done':'open'}]);
 return review('ما فيه قاعدة موثوقة لهذا الطلب. راجعه أو صنّفه يدويًا.');
}
export function answerContext(c:Clarification,answer:string,s:Store,ctx:Context):Context {
 const next={...ctx};const value=answer.trim();if(c.field==='date'){if(!validDate(value))throw Error('اكتب تاريخًا صالحًا YYYY-MM-DD');next.date=value}
 else if(c.field==='time'){if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(value))throw Error('حدد الوقت بصيغة 24 ساعة مثل 17:00');next.time=value}
 else if(c.field==='confirm'){if(value!=='yes')throw Error('يلزم تأكيد صريح');next.confirm=true}
 else if(c.field==='oil'){if(value!=='cooking'&&value!=='vehicle')throw Error('اختر نوع الزيت');next.oil=value}
 else if(c.field==='content'){if(value.length<3)throw Error('اكتب تفاصيل كافية');next.content=value}
 else {const kind=c.field==='vehicle'?'vehicle':c.field==='account'?'account':c.targetKind;const allowed=s.records.filter(r=>(!kind||r.kind===kind)&&(!c.choices?.length||c.choices.some(x=>x.value===r.id)));const matches=allowed.filter(r=>r.id===value||comparable(r.title)===comparable(value));if(matches.length!==1)throw Error('اختر سجلًا واحدًا من الخيارات أو اكتب اسمه كاملًا');next[c.field]=matches[0].id}
 return next;
}



