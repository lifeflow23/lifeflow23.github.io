import type {Store} from './model';
import {validateStore} from './validation';
import type {Repository} from './storage';
export class SharedRepository implements Repository {
 constructor(private token:string){}
 private async request(method:string,body?:unknown){const response=await fetch('/api/state',{method,headers:{Authorization:`Bearer ${this.token}`,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store',signal:AbortSignal.timeout(12000)});const result=await response.json();if(!response.ok)throw Error(result.error||'تعذر الاتصال بالكمبيوتر');validateStore(result);return result as Store}
 load(){return this.request('GET')}
 save(store:Store,expectedRevision:number){return this.request('PUT',{store,expectedRevision})}
}
