export const VERSION = 2;
export type Kind = 'task'|'event'|'grocery'|'account'|'transaction'|'vehicle'|'maintenance'|'issue'|'asset'|'person'|'followup'|'goal'|'note'|'document'|'price';
export type Recurrence = {unit:'day'|'week'|'month';interval:number;until?:string};
export interface RecordItem {
  id:string; kind:Kind; title:string; createdAt:string; updatedAt:string; sourceId?:string;
  category?:string; status?:'open'|'done'|'cancelled'|'returned'|'sold'; urgent?:boolean;
  date?:string; time?:string; endTime?:string; recurrence?:Recurrence; completedAt?:string;
  amountMinor?:number; type?:'income'|'expense'|'transfer'|'allocation'|'refund'|'reconciliation'|'allowance';
  accountId?:string; toAccountId?:string; relatedId?:string; personId?:string; vehicleId?:string;
  quantity?:string; favorite?:boolean; store?:string; mileage?:number; content?:string;
  targetMinor?:number; baselineIds?:string[]; fileData?:string; mime?:string;
}
export type NewRecord = Omit<RecordItem,'id'|'createdAt'|'updatedAt'>;
export type Action = {type:'create';key:string;record:NewRecord;linkKey?:string}|{type:'update';id:string;patch:Partial<RecordItem>}|{type:'query';kind?:Kind;query?:string;scope?:string;date?:string}|{type:'undo'};
export type Choice = {label:string;value:string};
export type Clarification = {field:'oil'|'vehicle'|'account'|'record'|'date'|'time'|'confirm'|'content';question:string;choices?:Choice[];targetKind?:Kind};
export type Context = {oil?:'cooking'|'vehicle';vehicle?:string;account?:string;record?:string;date?:string;time?:string;confirm?:boolean;content?:string};
export type Proposal = {outcome:'ready'|'clarify'|'review';reason:string;actions:Action[];clarification?:Clarification};
export interface Command {id:string;batchId:string;original:string;working:string;receivedAt:string;status:'completed'|'clarification'|'review'|'failed'|'cancelled';reason:string;context:Context;clarification?:Clarification;recordIds:string[];result?:string;duplicateOf?:string}
export interface Audit {id:string;commandId:string;at:string;before:RecordItem[];after:RecordItem[];undone?:boolean}
export interface Preferences {wallpaper:string;accent:string;dim:number;blur:number;theme:string;split:boolean;showQuote:boolean;quietStart:number;quietEnd:number;aliases:{id:string;word:string;kind:'vehicle'|'grocery';value:string}[];categories:string[];acknowledged:Record<string,string>}
export interface Store {schema:2;revision:number;records:RecordItem[];commands:Command[];audit:Audit[];preferences:Preferences}
export const emptyStore=():Store=>({schema:2,revision:0,records:[],commands:[],audit:[],preferences:{wallpaper:'aurora',accent:'lavender',dim:35,blur:0,theme:'Aurora Night',split:true,showQuote:true,quietStart:22,quietEnd:7,aliases:[],categories:['خضار','فواكه','ألبان','لحوم','مجمدات','مخبوزات','معلبات','مشروبات','تنظيف','عناية شخصية','مستلزمات منزل','حبوب ومؤن','حلويات وتسالي','غير مصنف'],acknowledged:{}}});
export const labels:Record<Kind,string>={task:'المهام',event:'المواعيد',grocery:'المشتريات',account:'الحسابات',transaction:'العمليات المالية',vehicle:'المركبات',maintenance:'الصيانة',issue:'مشاكل المنزل',asset:'الأصول والضمانات',person:'الأشخاص',followup:'المتابعات',goal:'الأهداف',note:'الذاكرة',document:'الملفات',price:'الأسعار'};
export const newId=()=>{const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;const hex=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');return [hex.slice(0,8),hex.slice(8,12),hex.slice(12,16),hex.slice(16,20),hex.slice(20)].join('-')};
