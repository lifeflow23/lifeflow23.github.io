import {useEffect,useState} from 'react';
interface InstallEvent extends Event {prompt():Promise<void>;userChoice:Promise<{outcome:string}>}
export function MobileInstall(){
 const [prompt,setPrompt]=useState<InstallEvent|null>(null);
 const [installed,setInstalled]=useState(()=>window.matchMedia('(display-mode: standalone)').matches);
 const [message,setMessage]=useState('');
 useEffect(()=>{const offered=(e:Event)=>{e.preventDefault();setPrompt(e as InstallEvent)};const done=()=>{setInstalled(true);setPrompt(null)};window.addEventListener('beforeinstallprompt',offered);window.addEventListener('appinstalled',done);return()=>{window.removeEventListener('beforeinstallprompt',offered);window.removeEventListener('appinstalled',done)}},[]);
 return <section className="settings-section"><h3>LifeFlow على جوالك</h3><p>{installed?'أنت تستخدم التطبيق من الشاشة الرئيسية.':'افتح الرابط في متصفح الجوال وأضفه للشاشة الرئيسية.'}</p>{prompt&&<button className="primary" onClick={async()=>{try{await prompt.prompt();const result=await prompt.userChoice;setMessage(result.outcome==='accepted'?'تم قبول طلب التثبيت؛ انتظر تأكيد المتصفح.':'تقدر تثبّته لاحقًا.');setPrompt(null)}catch{setMessage('استخدم قائمة المتصفح لإضافة التطبيق.')}}}>تثبيت LifeFlow</button>}<p>على iPhone: افتح الرابط في Safari، ثم مشاركة ← إضافة إلى الشاشة الرئيسية. على Android: من قائمة المتصفح اختر تثبيت التطبيق أو إضافة إلى الشاشة الرئيسية.</p><p>الحفظ والمعالجة على جوالك، بدون تشغيل الكمبيوتر. افتح التطبيق أول مرة مع الإنترنت لتحميل ملفاته. المزامنة بين الأجهزة غير مفعّلة؛ النسخ الاحتياطي متاح أدناه.</p>{message&&<p role="status">{message}</p>}</section>
}
