import {useEffect,useState} from 'react';
export default function PwaStatus(){
 const [ready,setReady]=useState(false);const [waiting,setWaiting]=useState<ServiceWorker|null>(null);const [error,setError]=useState(false);
 useEffect(()=>{if(!import.meta.env.PROD||!('serviceWorker' in navigator))return;let stopped=false;let reload=false;
 const changed=()=>{if(reload)location.reload()};navigator.serviceWorker.addEventListener('controllerchange',changed);
 navigator.serviceWorker.register(import.meta.env.BASE_URL+'sw.js',{scope:import.meta.env.BASE_URL}).then(reg=>{const inspect=()=>{if(stopped)return;if(reg.waiting)setWaiting(reg.waiting);if(reg.active)setReady(true)};inspect();reg.addEventListener('updatefound',()=>{const worker=reg.installing;worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&!stopped){if(navigator.serviceWorker.controller)setWaiting(reg.waiting);else setReady(true)}})});window.addEventListener('lifeflow-update',()=>{reload=true;reg.waiting?.postMessage({type:'SKIP_WAITING'})},{once:true})}).catch(()=>{if(!stopped)setError(true)});
 return()=>{stopped=true;navigator.serviceWorker.removeEventListener('controllerchange',changed)};
 },[]);
 return <>{ready&&!waiting&&<aside className="pwa-notice" role="status"><span>تم تحميل ملفات التطبيق للاستخدام دون اتصال.</span><button onClick={()=>setReady(false)} aria-label="إخفاء حالة التحميل">×</button></aside>}{waiting&&<aside className="pwa-notice" role="status"><span>تحديث متاح. احفظ أي إدخال مفتوح قبل التحديث.</span><button onClick={()=>window.dispatchEvent(new Event('lifeflow-update'))}>تحديث التطبيق</button></aside>}{error&&<aside className="pwa-notice" role="status">تعذر تجهيز نسخة دون اتصال. الحفظ المحلي متاح؛ افتح الرابط مع الإنترنت لاحقًا.</aside>}</>;
}
