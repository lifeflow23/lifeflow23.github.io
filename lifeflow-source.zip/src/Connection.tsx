import LocalApp from './local/LocalApp';
import {IndexedRepository} from './local/storage';
// Startup never waits for a server: the phone owns its database.
const repository=new IndexedRepository(new URLSearchParams(location.search).get('qa')==='1'?'lifeflow-isolated-qa-v2':'lifeflow-local-v2');
export default function Connection({showDemo}:{showDemo:()=>void}){return <LocalApp showDemo={showDemo} repository={repository}/>}
